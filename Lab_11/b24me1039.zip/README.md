# To run code:
Open the file in a code editor and in terminal use the command python filename.py to run the code.

Ensure that the file dataset.csv is in the same directory as the other files, and the python filename.py command will work when you are in the same directory, where the files are use cd command to change current directory.